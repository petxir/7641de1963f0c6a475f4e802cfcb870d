#!/bin/sh

./xmrig --coin XMR --url "xmr.kryptex.network:7777" --user 48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD/MyFirstRig -p x -k